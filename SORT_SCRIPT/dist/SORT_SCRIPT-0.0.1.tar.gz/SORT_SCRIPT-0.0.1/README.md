MY SORT SCRIPT
___________________________________________
Script can:
-Delete hollow dir in path you write in cmd
-Unpack archives
-Sort all known file by their type
____________________________________________
If you want to change amount of dir or file type , you can just change key and values in dictionary (dict_of_known_fileformat)
